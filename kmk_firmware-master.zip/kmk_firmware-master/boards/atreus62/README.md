# Atreus62

![Atreus62](https://assets.bigcartel.com/product_images/189335282/BIlqCtd.jpg?auto=format&fit=max&w=1200)

Atreus62 is a 60% column staggered keyboard pinky stagger 

kb.py is designed to work with the Teensy 4.1

Retailers (USA)  
[Atreus62](https://shop.profetkeyboards.com/product/atreus62-keyboard)  

Extensions enabled by default  
- [Layers](https://github.com/KMKfw/kmk_firmware/tree/master/docs/layers.md) Need more keys than switches? Use layers.
- [RGB](https://github.com/KMKfw/kmk_firmware/tree/master/docs/rgb.md) Light it up
- [Encoder](https://github.com/KMKfw/kmk_firmware/tree/master/docs/encoder.md) Twist control for all the things

