# Luddite

![Luddite](https://1.bp.blogspot.com/-GAAa-sMU_WU/W7uYLJJ8x1I/AAAAAAACS44/31n2z69BSboM4KT48YkNMJRYciC8LUMWgCLcBGAs/s640/a.jpg)

Luddite 60% keyboard with backlight and RGB underglow.  

kb.py is designed to work with the nice!nano
kb_converter.py is designed to work with an itsybitsy with converter board found [here](https://github.com/KMKfw/kmk_firmware/tree/master/hardware)

Hardware Availability: [Luddite project on 40% Keyboards](http://www.40percent.club/search/label/luddite)

Extensions enabled by default  
- [Layers](https://github.com/KMKfw/kmk_firmware/tree/master/docs/layers.md) Need more keys than switches? Use layers.
- [RGB](https://github.com/KMKfw/kmk_firmware/tree/master/docs/rgb.md) RGB underglow
- [LED](https://github.com/KMKfw/kmk_firmware/tree/master/docs/led.md) Light your keys up

Common Extensions
- [Power](https://github.com/KMKfw/kmk_firmware/tree/master/docs/power.md) Powersaving features for battery life
