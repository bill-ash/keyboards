# TG4X

![TG4X](https://boardsource.imgix.net/d50e1163-06dd-4c18-826e-caacd0a4a33d.jpg?raw=true)

TG4X is a 45% staggered keyboard, compared to a standard 40% stagger it has one additional column which makes it an approachable and highly use-able 40%-ish stagger. 

kb.py is designed to work with the nice!nano

Retailers (USA)  
[Boardsource](https://boardsource.xyz/store/5eff7ead037395179221b90c)  

Extensions enabled by default  
- [Layers](https://github.com/KMKfw/kmk_firmware/tree/master/docs/layers.md) Need more keys than switches? Use layers.
- [RGB](https://github.com/KMKfw/kmk_firmware/tree/master/docs/rgb.md) Light it up

Common Extensions
- [Power](https://github.com/KMKfw/kmk_firmware/tree/master/docs/power.md) Powersaving features for battery life
