# Suporte

Se você precisa de suporte com o KMK ou quer somente dizer oi, encontre-nos no
canal [#kmkfw:klar.sh no Matrix](https://matrix.to/#/#kmkfw:klar.sh). Este canal
tem uma ponte no Discord
[aqui](https://discordapp.com/widget?id=493256121075761173&theme=dark) por
conveniência.

Se você precisa de ajuda ou pretende abrir um bug report, se possível forneça o
hash SHA do *commit* utilizado, o qual pode ser obtido executando este comando
no REPL de seu controlador:

`from kmk.consts import KMK_RELEASE;  print(KMK_RELEASE)`
